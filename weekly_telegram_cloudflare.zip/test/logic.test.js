import test from "node:test";
import assert from "node:assert/strict";
import {
  classifyTelegramMessage,
  detectSubject,
  detectGroup,
  makeLectureAnnouncement,
  buildPublishPlan,
  appendHashtagToText,
  makeSectionsFooter,
  SUMMARIES_FOOTER,
} from "../src/logic.js";

function item(id, fileName, group, subject, received, extra = {}) {
  const message = extra.payload || { message_id: id, chat: { id: 123 }, document: { file_id: `file-${id}` } };
  return {
    id,
    file_name: fileName,
    display_name: fileName,
    group_type: group,
    subject_code: subject,
    media_kind: extra.mediaKind || "document",
    is_audio: extra.audio ? 1 : 0,
    section_number: extra.sectionNumber ?? null,
    lecture_number: extra.lectureNumber ?? null,
    is_answer: extra.answer ? 1 : 0,
    received_order: received,
    ignored: 0,
    payload_json: JSON.stringify(message),
  };
}

test("subject recognition uses the canonical subject codes", () => {
  assert.equal(detectSubject("AIS Lec 6 Chapter 3.pdf"), "AIS");
  assert.equal(detectSubject("CAS Sec 2 Answers.pdf"), "COST");
  assert.equal(detectSubject("MA Summary.pdf"), "MA");
  assert.equal(detectSubject("FR Lec 6.pdf"), "FR");
  assert.equal(detectSubject("AMA Advanced Managerial ACC.pdf"), "ADV");
  assert.equal(detectSubject("دراسات محاسبية محاضرة 6.pdf"), "STUDIES");
});

test("old lecture announcements, section footers and visual divider lines are detected for regeneration", () => {
  const lecture = classifyTelegramMessage({ text: "محاضرة 6 (AIS) 👆🏻\n\n#AIS" });
  const sections = classifyTelegramMessage({ text: "☝🏻 سكاشن الأسبوع الثاني" });
  const summaries = classifyTelegramMessage({ text: "☝🏻 ملخص محاضرة كل مادة الأسبوع ده" });
  const divider = classifyTelegramMessage({ text: "━━━━━━━━━━━━━━━━━━━━━━━━" });
  assert.equal(lecture.looksLikeGeneratedLectureAnnouncement, true);
  assert.equal(sections.looksLikeGeneratedGroupFooter, true);
  assert.equal(summaries.looksLikeGeneratedGroupFooter, true);
  assert.equal(divider.looksLikeDividerOnly, true);
});

test("group recognition keeps assignments and handouts in lectures", () => {
  assert.equal(detectGroup("AIS Assignment 6.pdf"), "lectures");
  assert.equal(detectGroup("AIS Lecture Handout.pdf"), "lectures");
  assert.equal(detectGroup("Sec 2 AIS Answers.pdf"), "sections");
  assert.equal(detectGroup("Sec2 AIS Answers.pdf"), "sections");
  assert.equal(detectGroup("AIS Summary.pdf"), "summaries");
});

test("lecture output sorts documents before audio and adds one subject announcement", () => {
  const items = [
    item(1, "Lec 6 AIS.m4a", "lectures", "AIS", 1, { audio: true, mediaKind: "audio", payload: { message_id: 1, audio: { file_id: "f1" } } }),
    item(2, "AIS Assignment 6.pdf", "lectures", "AIS", 2),
    item(3, "AIS Lec 6 Note.pdf", "lectures", "AIS", 3),
  ];
  const plan = buildPublishPlan(items, 6);
  const copies = plan.filter((entry) => entry.kind === "copy");
  assert.deepEqual(copies.map((entry) => entry.itemId), [2, 3, 1]);
  assert.equal(plan.at(-1).text, "محاضرة 6 (AIS) 👆🏻\n\n#AIS");
});

test("sections use subject order and place answers after the section file", () => {
  const items = [
    item(1, "Sec 1 FR Answers.pdf", "sections", "FR", 1, { sectionNumber: 1, answer: true }),
    item(2, "Sec 1 CAS.pdf", "sections", "COST", 2, { sectionNumber: 1 }),
    item(3, "Sec 1 AIS Answers.pdf", "sections", "AIS", 3, { sectionNumber: 1, answer: true }),
    item(4, "Sec 1 AIS.pdf", "sections", "AIS", 4, { sectionNumber: 1 }),
  ];
  const plan = buildPublishPlan(items, 6).filter((entry) => entry.kind === "copy");
  assert.deepEqual(plan.map((entry) => entry.itemId), [4, 3, 2, 1]);
  assert.ok(plan.every((entry) => entry.addHashtag));
});

test("summaries skip missing subjects and order by subject priority", () => {
  const items = [
    item(1, "FR Summary.pdf", "summaries", "FR", 1),
    item(2, "AIS Summary.pdf", "summaries", "AIS", 2),
  ];
  const plan = buildPublishPlan(items, 7).filter((entry) => entry.kind === "copy");
  assert.deepEqual(plan.map((entry) => entry.itemId), [2, 1]);
});

test("missing sections and summaries create no empty section divider", () => {
  const items = [item(1, "AIS Lec 6.pdf", "lectures", "AIS", 1)];
  const plan = buildPublishPlan(items, 6);
  assert.equal(plan.filter((entry) => entry.groupType === "sections").length, 0);
  assert.equal(plan.filter((entry) => entry.groupType === "summaries").length, 0);
});

test("exact hashtags are not duplicated, but wrong-case hashtags are corrected", () => {
  assert.equal(appendHashtagToText("Sec 1 AIS.pdf\n\n#AIS", "#AIS"), "Sec 1 AIS.pdf\n\n#AIS");
  assert.equal(appendHashtagToText("Sec 1 AIS.pdf\n\n#ais", "#AIS"), "Sec 1 AIS.pdf\n\n#ais\n\n#AIS");
});

test("MA and Cost System announcement templates preserve exact hashtag casing", () => {
  assert.equal(makeLectureAnnouncement(4, "MA"), "محاضرة 4 (MA)👆🏻\n\n#Managerial_ACC");
  assert.equal(makeLectureAnnouncement(4, "COST"), "محاضرة 4 (Cost System) 👆🏻\n\n#cost_system");
});


test("sections footer uses Sec number, not the lecture week number", () => {
  const sections = [
    item(1, "Sec 2 AIS.pdf", "sections", "AIS", 1, { sectionNumber: 2 }),
    item(2, "Sec 2 CAS.pdf", "sections", "COST", 2, { sectionNumber: 2 }),
  ];
  assert.equal(makeSectionsFooter(sections), "☝🏻 سكاشن الأسبوع الثاني");
  assert.equal(SUMMARIES_FOOTER, "☝🏻 ملخص محاضرة كل مادة الأسبوع ده");
});
